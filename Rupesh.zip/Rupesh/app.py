from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model and scaler
model = joblib.load('model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/')
def index():
    return render_template('index.html')  # Your HTML form

@app.route('/predict_datapoint', methods=['POST'])
def predict_datapoint():
    data = {
        'temp': float(request.form['temp']),
        'turbidity': float(request.form['turbidity']),
        'do': float(request.form['do']),
        'bod': float(request.form['bod']),
        'co2': float(request.form['co2']),
        'ph': float(request.form['ph']),
        'alkalinity': float(request.form['alkalinity']),
        'hardness': float(request.form['hardness']),
        'calcium': float(request.form['calcium']),
        'ammonia': float(request.form['ammonia']),
        'nitrite': float(request.form['nitrite']),
        'phosphorus': float(request.form['phosphorus']),
        'h2s': float(request.form['h2s']),
        'plankton': float(request.form['plankton'])
    }

    input_data = scaler.transform([list(data.values())])
    prediction = model.predict(input_data)[0]
    
    result_msg = "Water is Safe and Clean!" if prediction == 1 else "Water Quality is Poor or Contaminated!"

    return render_template("result.html", data=data, result=result_msg)


if __name__ == '__main__':
    app.run(debug=True)
